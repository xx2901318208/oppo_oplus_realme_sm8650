#!/system/bin/sh

MODDIR=${0%/*}
CONFIG="$MODDIR/zram_config.conf"
LOG="$MODDIR/zram.log"

# 支持的算法和大小配置
algorithms="lz4 lz4k lz4kd lz4hc zstd zstdn lzo lzo-rle 842 lz4k_oplus"
sizes="8589934592 12884901888 17179869184 25769803776"  # 8G, 12G, 16G, 24G

# 日志记录函数
log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG"
}

show_device_info() {
    local model=$(getprop ro.product.model || echo '未知')
    local android=$(getprop ro.build.version.release || echo '未知')
    local kernel=$(uname -r || echo '未知')
    
    echo "🔧 设备: $model"
    echo "🔄 Android: $android"
    echo "⚙️ 内核: $kernel"
    
    log_message "设备信息 - 型号: $model, Android: $android, 内核: $kernel"
}

get_real_ram_bytes() {
  awk '/MemTotal/ {if($2>0) print $2*1024; else print 0}' /proc/meminfo 2>/dev/null || echo "0"
}

check_dual_zram() {
  [ -e /sys/block/zram0 ] && [ -e /sys/block/zram1 ] && echo "是" || echo "否"
}

get_active_algorithm() {
  alg=$(cat /sys/block/zram0/comp_algorithm 2>/dev/null | grep -o '\[[^]]*\]' | tr -d '[]')
  echo "${alg:-lz4kd}"
}

wait_key() {
  getevent -qt 1 >/dev/null 2>&1
  while true; do
    event=$(getevent -lqc 1 2>/dev/null | {
      while read -r line; do
        case "$line" in
          *KEY_VOLUMEDOWN*DOWN*) echo "down" && break ;;
          *KEY_VOLUMEUP*DOWN*) echo "up" && break ;;
          *KEY_POWER*DOWN*)
            input keyevent KEY_POWER
            echo "power" && break ;;
        esac
      done
    })
    [ -n "$event" ] && echo "$event" && return
    usleep 50000
  done
}

countdown() {
  local secs=$1
  while [ $secs -gt 0 ]; do
    echo -ne "⏳ ${secs}秒后返回...\033[0K\r"
    sleep 1
    : $((secs--))
  done
  echo -e "\033[0K\r"
}

RAM_BYTES=$(get_real_ram_bytes)
IS_DUAL_ZRAM=$(check_dual_zram)
current_alg=$(get_active_algorithm)

index=0
alg_count=$(echo "$algorithms" | wc -w)
for alg in $algorithms; do
  if [ "$alg" = "$current_alg" ]; then break; fi
  index=$((index + 1))
done
[ $index -ge $alg_count ] && index=0 && current_alg=$(echo "$algorithms" | cut -d' ' -f$((index + 1)))

current_size=$(cat /sys/block/zram0/disksize 2>/dev/null || echo 0)
size_index=0
j=0
for sz in $sizes; do
  if [ "$sz" -eq "$current_size" ]; then
    size_index=$j
    break
  fi
  j=$((j + 1))
done
size_count=$(echo "$sizes" | wc -w)
[ $size_index -ge $size_count ] && size_index=0

SIZE_TO_APPLY=$(echo "$sizes" | cut -d' ' -f$((size_index + 1)))
size_rem=$(echo "$SIZE_TO_APPLY" | awk '{if($1<=0) print "未知"; else printf "%.1fGB", $1/1024/1024/1024}')

show_menu() {
  clear
  echo "ZRAM 配置管理器² 😋"
  echo "----------------------------------"
  show_device_info
  echo "----------------------------------"
  echo "📊 物理内存: $(echo "$RAM_BYTES" | awk '{if($1<=0) print "未知"; else printf "%.1fGB", $1/1024/1024/1024}')"
  echo "💽 双ZRAM: $IS_DUAL_ZRAM"
  echo "----------------------------------"
  echo "📦 压缩算法选择:"
  local i=0
  for alg in $algorithms; do
    [ $i -eq $index ] && echo "➡️  $alg [当前: $current_alg]" || echo "    $alg"
    i=$((i + 1))
  done
  echo "----------------------------------"
  echo "💾 ZRAM 大小设置:"
  local j=0
  for sz in $sizes; do
    human_sz=$(echo "$sz" | awk '{printf "%.1fGB", $1/1024/1024/1024}')
    [ $j -eq $size_index ] && echo "➡️  $human_sz [当前 $size_rem]" || echo "    $human_sz"
    j=$((j + 1))
  done
  echo "----------------------------------"
  echo "🔽 音量下：切换算法 | 🔼 音量上：切换大小"
  echo "🔌 电源键：应用并退出"
  echo "----------------------------------"
  echo "配置将保存到模块目录: $MODDIR/zram_config.conf"
  echo ""
}

apply_zram_config() {
    local selected_alg=$1
    local size_to_apply=$2
    local human_size=$(echo "$size_to_apply" | awk '{printf "%.1fGB", $1/1024/1024/1024}')
    
    log_message "开始应用新配置 - 算法: $selected_alg, 大小: $size_to_apply ($human_size)"
    
    su -c "
        swapoff /dev/block/zram0 2>/dev/null
        echo 1 > /sys/block/zram0/reset
        echo $selected_alg > /sys/block/zram0/comp_algorithm
        echo $size_to_apply > /sys/block/zram0/disksize
        mkswap /dev/block/zram0 >/dev/null
        swapon -p 32767 /dev/block/zram0 >/dev/null
    "
    
    local result=$?
    [ $result -eq 0 ] && log_message "ZRAM配置应用成功" || log_message "ZRAM配置应用失败"
    return $result
}

save_config() {
    local alg=$1
    local size=$2
    local human_size=$(echo "$size" | awk '{printf "%.1fGB", $1/1024/1024/1024}')
    
    log_message "保存配置到文件 - 算法: $alg, 大小: $size"
    
    # 保存到配置文件
    su -c "cat > \"$CONFIG\" <<EOF
algorithm=$alg
size=$size
EOF"
    
    local save_result=$?
    if [ $save_result -eq 0 ]; then
        log_message "配置文件保存成功"
        
        # 更新module.prop
        local MODULE_PROP="$MODDIR/module.prop"
        if [ -f "$MODULE_PROP" ]; then
            local new_description="description=当前已生效 [ZRAM大小($human_size) 压缩算法($alg)]"
            su -c "sed -i 's/^description=.*/$new_description/' \"$MODULE_PROP\""
            log_message "module.prop更新成功"
        fi
    else
        log_message "配置文件保存失败"
    fi
    
    return $save_result
}

while true; do
    show_menu
    case $(wait_key) in
        "down")
            index=$(( (index + 1) % $alg_count ))
            current_alg=$(echo "$algorithms" | cut -d' ' -f$((index + 1)))
            log_message "用户切换算法到: $current_alg"
            ;;
        "up")
            size_index=$(( (size_index + 1) % $size_count ))
            SIZE_TO_APPLY=$(echo "$sizes" | cut -d' ' -f$((size_index + 1)))
            local human_size=$(echo "$SIZE_TO_APPLY" | awk '{printf "%.1fGB", $1/1024/1024/1024}')
            log_message "用户切换大小到: $SIZE_TO_APPLY ($human_size)"
            ;;
        "power")
            selected_alg=$(echo "$algorithms" | cut -d' ' -f$((index + 1)))
            clear
            echo "🛠️ 正在应用配置..."
            echo "----------------------------------"
            echo "选定算法: $selected_alg"
            echo "目标大小: $(echo "$SIZE_TO_APPLY" | awk '{printf "%.1fGB", $1/1024/1024/1024}') ($SIZE_TO_APPLY 字节)"
            echo "双ZRAM: $IS_DUAL_ZRAM"
            echo "----------------------------------"

            apply_zram_config "$selected_alg" "$SIZE_TO_APPLY"
            sleep 1
            
            new_alg=$(get_active_algorithm)
            new_size=$(cat /sys/block/zram0/disksize 2>/dev/null || echo "0")

            clear
            echo "🔧 ZRAM 配置管理器"
            echo "----------------------------------"

            if [ "$new_alg" = "$selected_alg" ] && [ "$new_size" -eq "$SIZE_TO_APPLY" ]; then
                echo "✅ 全部都搞定了❛˓◞˂̵✧"
                echo "实际算法: $new_alg"
                echo "实际大小: $(echo "$new_size" | awk '{printf "%.1fGB", $1/1024/1024/1024}')"
                
                save_config "$new_alg" "$new_size"
                [ $? -eq 0 ] && echo "✅ 配置文件保存成功。" || echo "❌ 配置文件保存失败！"
            else
                log_message "配置应用失败 - 期望算法: $selected_alg, 实际: $new_alg, 期望大小: $SIZE_TO_APPLY, 实际: $new_size"
                echo "❌ 设置失败或部分未生效"
            fi
            
            echo "----------------------------------"
            countdown 3
            log_message "用户退出配置管理器"
            exit 0
            ;;
    esac
done
